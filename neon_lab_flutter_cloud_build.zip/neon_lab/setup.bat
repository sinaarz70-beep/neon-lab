@echo off
call flutter create --org com.sina --project-name neon_lab --platforms android .
xcopy /E /Y android_overrides\* android\
call flutter pub get
call dart run flutter_launcher_icons
echo Done. Now run: flutter run
