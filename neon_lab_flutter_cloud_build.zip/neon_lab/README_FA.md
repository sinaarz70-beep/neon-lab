# آزمایشگاه نئون: راهنمای ساخت و انتشار در گوگل پلی

## ۱. پیش‌نیازها
- نصب Flutter (نسخه ۳.۲۲ یا جدیدتر) و Android Studio
- در ترمینال `flutter doctor` بزن تا مطمئن شی همه‌چیز سبزه

## ۲. آماده‌سازی پروژه (فقط یک بار)
پوشه رو از حالت فشرده دربیار، ترمینال رو داخلش باز کن و:
- ویندوز: `setup.bat`
- مک/لینوکس: `./setup.sh`

این اسکریپت پوشه android رو می‌سازه، تنظیمات بازی و آیکون رو روش می‌ذاره.

## ۳. تست روی گوشی
گوشی رو با USB وصل کن (USB debugging روشن باشه) و بزن: `flutter run`

## ۴. ساخت کلید امضا (فقط یک بار، این فایل رو گم نکن!)
```
keytool -genkey -v -keystore upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```
فایل `android_overrides/key.properties.example` رو به `android/key.properties` کپی کن و رمزها و مسیر فایل رو بنویس.

بعد فایل `android/app/build.gradle.kts` رو باز کن و این‌ها رو اضافه کن:

بالای فایل:
```kotlin
import java.util.Properties
import java.io.FileInputStream
val keystoreProperties = Properties().apply {
    val f = rootProject.file("key.properties")
    if (f.exists()) load(FileInputStream(f))
}
```
داخل بلوک `android { ... }`:
```kotlin
signingConfigs {
    create("release") {
        keyAlias = keystoreProperties["keyAlias"] as String
        keyPassword = keystoreProperties["keyPassword"] as String
        storeFile = file(keystoreProperties["storeFile"] as String)
        storePassword = keystoreProperties["storePassword"] as String
    }
}
```
و داخل `buildTypes { release { ... } }` خط `signingConfig = signingConfigs.getByName("debug")` رو عوض کن به:
```kotlin
signingConfig = signingConfigs.getByName("release")
```
(اگه پروژه‌ات `build.gradle` بدون kts ساخت، همین کار با سینتکس Groovy انجام می‌شه: راهنمای رسمی docs.flutter.dev/deployment/android)

## ۵. ساخت فایل نهایی
```
flutter build appbundle
```
خروجی: `build/app/outputs/bundle/release/app-release.aab`

## ۶. جدول مسابقه جهانی (Google Play Games)
1. در Play Console اپ رو بساز (اکانت توسعه‌دهنده یک بار ۲۵ دلار)
2. منوی **Play Games Services > Setup and management > Configuration** رو باز کن و سرویس رو بساز
3. یک **Credential** نوع Android اضافه کن (SHA-1 کلید رو با `keytool -list -v -keystore upload-keystore.jks` بگیر؛ بعد از اولین آپلود، SHA-1 بخش App signing گوگل رو هم اضافه کن)
4. در **Leaderboards** یک جدول بساز: نام «امتیاز کل»، ترتیب «Larger is better»
5. عدد **Project ID** رو در `android/app/src/main/res/values/games-ids.xml` بذار
6. **Leaderboard ID** رو در `lib/services/play_games.dart` جای `REPLACE_WITH_LEADERBOARD_ID` بذار
7. در بخش **Testers** ایمیل خودت رو اضافه کن تا قبل از انتشار تست کنی، بعد سرویس رو Publish کن

## ۷. آپلود در گوگل پلی
- Testing > Internal testing > Create release > فایل aab رو آپلود کن
- Store listing: متن‌های آماده توی `store/listing_fa.md`، آیکون ۵۱۲ و تصویر ویژه ۱۰۲۴×۵۰۰ توی پوشه store
- حداقل ۲ اسکرین‌شات از گوشی بگیر و آپلود کن
- Privacy policy: متن `store/privacy_fa.md` رو جایی (مثلاً Google Sites) منتشر کن و لینکش رو بده
- پرسشنامه Content rating و Data safety رو پر کن (بازی داده شخصی جمع نمی‌کنه، فقط ورود Play Games)
- نکته: اکانت‌های شخصی جدید باید اول ۱۴ روز با حداقل ۱۲ تستر Closed testing انجام بدن تا اجازه انتشار عمومی بگیرن

## ساختار کد
- `lib/game/logic.dart`: قوانین، تولید مرحله‌های بی‌نهایت که همیشه قابل حل‌ان، امتیازدهی
- `lib/screens/game_screen.dart`: صفحه بازی و انیمیشن ریختن
- `lib/screens/board_screen.dart`: جدول مسابقه
- `lib/theme.dart`: رنگ‌های نئونی (برای عوض کردن رنگ‌ها همین‌جا)
- `lib/services/play_games.dart`: اتصال به جدول جهانی گوگل
