#!/usr/bin/env bash
# یک بار اجرا کن: پوشه android ساخته می‌شه و تنظیمات بازی روش اعمال می‌شه
set -e
flutter create --org com.sina --project-name neon_lab --platforms android .
cp -r android_overrides/* android/
flutter pub get
dart run flutter_launcher_icons
echo "آماده‌ست! حالا: flutter run"
