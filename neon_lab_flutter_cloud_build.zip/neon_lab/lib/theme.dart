import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Neon {
  static const night = Color(0xFF0A0420);
  static const plum = Color(0xFF1A0B3D);
  static const cyan = Color(0xFF00EAFF);
  static const magenta = Color(0xFFFF2BD6);
  static const yellow = Color(0xFFFFE600);
  static const text = Color(0xFFEFE9FF);
  static const muted = Color(0xFFB9AEE0);
  static const glass = Color(0xAACFC6F0);

  /// Fluorescent liquid colors.
  static const liquids = <Color>[
    Color(0xFF00EAFF), Color(0xFFFF2BD6), Color(0xFFFFE600), Color(0xFF39FF14),
    Color(0xFFFF6A00), Color(0xFFA64DFF), Color(0xFFFF1F4B), Color(0xFF00FFB3),
    Color(0xFF3D6BFF), Color(0xFFFFFFFF), Color(0xFFFF9EE6), Color(0xFFC8FF00),
  ];

  static List<Shadow> glow(Color c, [double r = 18]) => [
        Shadow(color: c, blurRadius: r * .35),
        Shadow(color: c, blurRadius: r),
        Shadow(color: c.withOpacity(.6), blurRadius: r * 2.2),
      ];

  static TextStyle font({double size = 16, FontWeight w = FontWeight.w500, Color color = text, List<Shadow>? shadows, double? height}) =>
      GoogleFonts.vazirmatn(fontSize: size, fontWeight: w, color: color, shadows: shadows, height: height);
}

String fa(int n) {
  const d = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return n.toString().split('').map((c) {
    final i = int.tryParse(c);
    return i == null ? c : d[i];
  }).join();
}
