import 'package:flutter/material.dart';
import '../services/play_games.dart';
import '../services/store.dart';
import '../theme.dart';
import '../widgets/neon_button.dart';

class BoardScreen extends StatefulWidget {
  final int score;
  const BoardScreen({super.key, required this.score});
  @override
  State<BoardScreen> createState() => _BoardScreenState();
}

class _BoardScreenState extends State<BoardScreen> {
  List<Record> records = [];

  @override
  void initState() {
    super.initState();
    Store.records().then((r) {
      if (!mounted) return;
      final best = [...r]..sort((a, b) => b.points.compareTo(a.points));
      setState(() => records = best.take(20).toList());
    });
  }

  Future<void> _openGlobal() async {
    final ok = await PlayGames.showLeaderboard();
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: Neon.plum,
        content: Text('ورود به Google Play Games انجام نشد', style: Neon.font(size: 15)),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    const medal = [Neon.yellow, Neon.cyan, Neon.magenta];
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 22),
      Text('جدول مسابقه', style: Neon.font(size: 44, w: FontWeight.w900, color: Neon.magenta, shadows: Neon.glow(Neon.magenta, 14), height: 1.1)),
      const SizedBox(height: 6),
      Text('امتیاز کل تو: ${fa(widget.score)}', style: Neon.font(size: 17, w: FontWeight.w700, color: Neon.yellow)),
      const SizedBox(height: 18),
      NeonPill(label: 'رتبه‌بندی جهانی', color: Neon.cyan, onTap: _openGlobal),
      const SizedBox(height: 24),
      Text('بهترین مرحله‌های تو', style: Neon.font(size: 15, w: FontWeight.w700, color: Neon.muted)),
      const SizedBox(height: 10),
      Expanded(
        child: records.isEmpty
            ? Center(child: Text('هنوز مرحله‌ای تموم نکردی. برو بازی کن!', style: Neon.font(size: 16, color: Neon.muted)))
            : ListView.separated(
                padding: const EdgeInsets.only(bottom: 20),
                itemCount: records.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (_, i) {
                  final r = records[i];
                  final c = i < 3 ? medal[i] : const Color(0xFF7D71A8);
                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(.04),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: i == 0 ? Neon.cyan : Colors.white.withOpacity(.08)),
                      boxShadow: i == 0 ? [BoxShadow(color: Neon.cyan.withOpacity(.3), blurRadius: 14)] : null,
                    ),
                    child: Row(children: [
                      SizedBox(
                        width: 34,
                        child: Text(fa(i + 1), textAlign: TextAlign.center, style: Neon.font(size: 24, w: FontWeight.w900, color: c, shadows: i < 3 ? Neon.glow(c, 8) : null)),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('مرحله ${fa(r.level)}', style: Neon.font(size: 17, w: FontWeight.w700)),
                          Text('${fa(r.moves)} حرکت', style: Neon.font(size: 14, color: Neon.muted)),
                        ]),
                      ),
                      Text(fa(r.points), style: Neon.font(size: 22, w: FontWeight.w900, color: Neon.yellow)),
                    ]),
                  );
                },
              ),
      ),
    ]);
  }
}
