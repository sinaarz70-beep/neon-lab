import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../game/logic.dart';
import '../services/play_games.dart';
import '../services/store.dart';
import '../theme.dart';
import '../widgets/neon_button.dart';
import '../widgets/tube.dart';

class _Pour {
  final int from;
  final Rect start;
  final Offset mouth;
  final double dir;
  final int color;
  final double streamH;
  bool pouring = false;
  _Pour(this.from, this.start, this.mouth, this.dir, this.color, this.streamH);
}

class GameScreen extends StatefulWidget {
  final VoidCallback onOpenBoard;
  final ValueChanged<int> onScore;
  const GameScreen({super.key, required this.onOpenBoard, required this.onScore});
  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with SingleTickerProviderStateMixin {
  int level = 1;
  int score = 0;
  Tubes tubes = [];
  final List<Tubes> history = [];
  int? selected;
  bool extraUsed = false;
  int moves = 0;
  bool busy = false;
  bool loaded = false;
  int? flash;
  _Pour? anim;
  double seg = 34, tubeW = 48;

  final stackKey = GlobalKey();
  final keys = List.generate(20, (_) => GlobalKey());
  late final AnimationController ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 300));

  @override
  void initState() {
    super.initState();
    Store.load().then((p) {
      if (!mounted) return;
      setState(() {
        level = p.level;
        score = p.score;
        _reset();
        loaded = true;
      });
      widget.onScore(score);
    });
  }

  @override
  void dispose() {
    ctrl.dispose();
    super.dispose();
  }

  void _reset() {
    tubes = makeLevel(level);
    history.clear();
    selected = null;
    extraUsed = false;
    moves = 0;
    anim = null;
    busy = false;
    ctrl.value = 0;
  }

  void _tap(int i) {
    if (busy) return;
    final t = tubes[i];
    if (selected == null) {
      if (t.isEmpty || isDoneTube(t)) {
        HapticFeedback.lightImpact();
        return;
      }
      setState(() => selected = i);
      HapticFeedback.selectionClick();
      return;
    }
    if (selected == i) {
      setState(() => selected = null);
      return;
    }
    if (!canPour(tubes, selected!, i)) {
      HapticFeedback.heavyImpact();
      setState(() => selected = (t.isNotEmpty && !isDoneTube(t)) ? i : null);
      return;
    }
    _pour(selected!, i);
  }

  Rect _rectOf(int i) {
    final stackBox = stackKey.currentContext!.findRenderObject() as RenderBox;
    final box = keys[i].currentContext!.findRenderObject() as RenderBox;
    return box.localToGlobal(Offset.zero, ancestor: stackBox) & box.size;
  }

  Future<void> _pour(int a, int b) async {
    busy = true;
    final ra = _rectOf(a).shift(const Offset(0, -22)); // it was lifted
    final rb = _rectOf(b);
    final dir = rb.left >= ra.left ? 1.0 : -1.0;
    final glassTopB = rb.top + kCapSpace;
    final mouth = Offset(rb.center.dx - dir * 6, glassTopB - seg * 1.35);
    final streamH = glassTopB - mouth.dy + (cap - tubes[b].length) * seg + 8;
    final res = pour(tubes, a, b);
    setState(() {
      selected = null;
      anim = _Pour(a, ra, mouth, dir, res.color, streamH);
    });
    HapticFeedback.selectionClick();
    await ctrl.animateTo(1, duration: const Duration(milliseconds: 300), curve: Curves.easeOutCubic);
    if (!mounted) return;
    setState(() {
      history.add(tubes);
      tubes = res.tubes;
      moves++;
      anim!.pouring = true;
      if (isDoneTube(tubes[b]) && tubes[b].isNotEmpty) flash = b;
    });
    await Future.delayed(Duration(milliseconds: 120 * res.moved + 260));
    if (!mounted) return;
    setState(() {
      anim!.pouring = false;
      flash = null;
    });
    await ctrl.animateBack(0, duration: const Duration(milliseconds: 300), curve: Curves.easeInOutCubic);
    if (!mounted) return;
    setState(() => anim = null);
    busy = false;
    if (isWon(tubes)) _win();
  }

  Future<void> _win() async {
    final p = pointsFor(level, moves, extraUsed);
    final finished = level;
    final m = moves;
    score += p;
    level += 1;
    await Store.save(level, score);
    await Store.addRecord(Record(finished, m, p, DateTime.now()));
    PlayGames.submit(score);
    widget.onScore(score);
    HapticFeedback.mediumImpact();
    if (!mounted) return;
    await Future.delayed(const Duration(milliseconds: 350));
    if (!mounted) return;
    final openBoard = await showGeneralDialog<bool>(
      context: context,
      barrierDismissible: false,
      barrierColor: const Color(0xB305010F),
      transitionDuration: const Duration(milliseconds: 380),
      pageBuilder: (_, __, ___) => _WinCard(level: finished, moves: m, points: p),
      transitionBuilder: (_, a, __, child) => Opacity(
        opacity: a.value,
        child: Transform.translate(offset: Offset(0, 30 * (1 - Curves.easeOutBack.transform(a.value))), child: child),
      ),
    );
    if (!mounted) return;
    setState(_reset);
    if (openBoard == true) widget.onOpenBoard();
  }

  void _undo() {
    if (busy || history.isEmpty) return;
    setState(() {
      tubes = history.removeLast();
      selected = null;
    });
  }

  void _addTube() {
    if (busy || extraUsed) return;
    setState(() {
      tubes = [...tubes, <int>[]];
      extraUsed = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!loaded) return const SizedBox.shrink();
    return Column(children: [
      const SizedBox(height: 18),
      _header(),
      Expanded(child: _board()),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        NeonTool(icon: Icons.add_circle_outline, label: 'لوله اضافه', onTap: extraUsed ? null : _addTube),
        const SizedBox(width: 26),
        NeonTool(icon: Icons.refresh_rounded, label: 'از نو', onTap: () => busy ? null : setState(_reset)),
        const SizedBox(width: 26),
        NeonTool(icon: Icons.undo_rounded, label: 'برگشت', onTap: history.isEmpty ? null : _undo),
      ]),
      const SizedBox(height: 18),
    ]);
  }

  Widget _header() {
    return Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('مرحله', style: Neon.font(size: 15, w: FontWeight.w700, color: Neon.magenta, shadows: Neon.glow(Neon.magenta, 10))),
        Text(fa(level), style: Neon.font(size: 84, w: FontWeight.w900, color: const Color(0xFFE8FDFF), shadows: Neon.glow(Neon.cyan), height: 1)),
      ]),
      const Spacer(),
      Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text('امتیاز', style: Neon.font(size: 14, color: Neon.muted)),
        Text(fa(score), style: Neon.font(size: 28, w: FontWeight.w900, color: Neon.yellow, shadows: Neon.glow(Neon.yellow, 8))),
        Text('${fa(moves)} حرکت', style: Neon.font(size: 14, color: Neon.muted)),
        const SizedBox(height: 8),
      ]),
    ]);
  }

  Widget _board() {
    return LayoutBuilder(builder: (context, c) {
      final n = tubes.length;
      final perRow = n <= 6 ? n : (n / (n / 6).ceil()).ceil();
      final rowsCount = (n / perRow).ceil();
      const gap = 14.0;
      final byWidth = (c.maxWidth - gap * (perRow - 1)) / perRow / 48;
      final byHeight = (c.maxHeight - 40 * (rowsCount - 1) - 60) / rowsCount / TubeView.heightFor(34);
      final s = min(1.0, min(byWidth, byHeight));
      tubeW = 48 * s;
      seg = 34 * s;

      final rows = <Widget>[];
      for (var r = 0; r < rowsCount; r++) {
        final items = <Widget>[];
        for (var i = r * perRow; i < min(n, (r + 1) * perRow); i++) {
          if (items.isNotEmpty) items.add(const SizedBox(width: gap));
          items.add(_tube(i));
        }
        if (r > 0) rows.add(const SizedBox(height: 40));
        rows.add(Row(mainAxisAlignment: MainAxisAlignment.center, children: items));
      }

      return Stack(key: stackKey, clipBehavior: Clip.none, children: [
        Positioned.fill(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: rows)),
        if (anim != null && anim!.pouring)
          Positioned(
            left: anim!.mouth.dx - 3,
            top: anim!.mouth.dy,
            child: Container(
              width: 6,
              height: anim!.streamH,
              decoration: BoxDecoration(
                color: Neon.liquids[anim!.color],
                borderRadius: BorderRadius.circular(3),
                boxShadow: [BoxShadow(color: Neon.liquids[anim!.color], blurRadius: 12)],
              ),
            ),
          ),
        if (anim != null)
          AnimatedBuilder(
            animation: ctrl,
            builder: (_, __) {
              final t = ctrl.value;
              final a = anim!;
              final target = Offset(a.mouth.dx - tubeW / 2, a.mouth.dy - kCapSpace);
              final pos = Offset.lerp(a.start.topLeft, target, t)!;
              return Positioned(
                left: pos.dx,
                top: pos.dy,
                child: Transform.rotate(
                  angle: a.dir * 72 * pi / 180 * t,
                  alignment: Alignment.topCenter,
                  child: TubeView(tube: tubes[a.from], width: tubeW, seg: seg),
                ),
              );
            },
          ),
      ]);
    });
  }

  Widget _tube(int i) {
    final hidden = anim != null && anim!.from == i;
    final sel = selected == i;
    return GestureDetector(
      key: keys[i],
      behavior: HitTestBehavior.opaque,
      onTap: () => _tap(i),
      child: Opacity(
        opacity: hidden ? 0 : 1,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          transform: Matrix4.translationValues(0, sel ? -22 : 0, 0),
          child: TubeView(tube: tubes[i], width: tubeW, seg: seg, glow: sel ? Neon.cyan : null, flash: flash == i),
        ),
      ),
    );
  }
}

class _WinCard extends StatelessWidget {
  final int level, moves, points;
  const _WinCard({required this.level, required this.moves, required this.points});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Center(
        child: Material(
          color: Colors.transparent,
          child: Container(
            width: 330,
            padding: const EdgeInsets.fromLTRB(28, 32, 28, 22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF1F0D47), Color(0xFF12062B)]),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: Neon.magenta.withOpacity(.45), width: 1.5),
              boxShadow: [BoxShadow(color: Neon.magenta.withOpacity(.25), blurRadius: 40)],
            ),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(5, (k) {
                  final c = Neon.liquids[(level + k) % Neon.liquids.length];
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: 14,
                    height: 44,
                    decoration: BoxDecoration(
                      color: c,
                      borderRadius: const BorderRadius.vertical(bottom: Radius.circular(8)),
                      boxShadow: [BoxShadow(color: c, blurRadius: 14)],
                    ),
                  );
                }),
              ),
              const SizedBox(height: 20),
              Text('عالی بود!', style: Neon.font(size: 34, w: FontWeight.w900, color: const Color(0xFFE8FDFF), shadows: Neon.glow(Neon.cyan))),
              const SizedBox(height: 6),
              Text('مرحله ${fa(level)} در ${fa(moves)} حرکت', style: Neon.font(size: 16, color: Neon.muted)),
              const SizedBox(height: 10),
              Text('+${fa(points)}', style: Neon.font(size: 30, w: FontWeight.w900, color: Neon.yellow, shadows: Neon.glow(Neon.yellow, 8))),
              const SizedBox(height: 22),
              NeonPill(label: 'مرحله بعد', onTap: () => Navigator.of(context).pop(false)),
              TextButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: Text('دیدن جدول مسابقه', style: Neon.font(size: 15, w: FontWeight.w700, color: Neon.cyan)),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
