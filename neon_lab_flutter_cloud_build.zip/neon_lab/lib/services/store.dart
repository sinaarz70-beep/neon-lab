import 'package:shared_preferences/shared_preferences.dart';

class Record {
  final int level, moves, points;
  final DateTime at;
  Record(this.level, this.moves, this.points, this.at);
  String encode() => '$level|$moves|$points|${at.millisecondsSinceEpoch}';
  static Record? decode(String s) {
    final p = s.split('|');
    if (p.length != 4) return null;
    return Record(int.parse(p[0]), int.parse(p[1]), int.parse(p[2]), DateTime.fromMillisecondsSinceEpoch(int.parse(p[3])));
  }
}

class Progress {
  final int level, score;
  const Progress(this.level, this.score);
}

class Store {
  static Future<Progress> load() async {
    final p = await SharedPreferences.getInstance();
    return Progress(p.getInt('level') ?? 1, p.getInt('score') ?? 0);
  }

  static Future<void> save(int level, int score) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('level', level);
    await p.setInt('score', score);
  }

  static Future<void> addRecord(Record r) async {
    final p = await SharedPreferences.getInstance();
    final list = p.getStringList('records') ?? <String>[];
    list.insert(0, r.encode());
    await p.setStringList('records', list.take(100).toList());
  }

  static Future<List<Record>> records() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList('records') ?? <String>[]).map(Record.decode).whereType<Record>().toList();
  }
}
