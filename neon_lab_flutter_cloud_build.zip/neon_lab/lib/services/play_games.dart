import 'package:games_services/games_services.dart';

/// Google Play Games leaderboard. Replace the ID with the one from Play Console
/// (Play Games Services > Leaderboards). See README_FA.md step 6.
class PlayGames {
  static const leaderboardId = 'REPLACE_WITH_LEADERBOARD_ID';
  static bool signedIn = false;

  static Future<bool> signIn() async {
    try {
      await GamesServices.signIn();
      signedIn = true;
    } catch (_) {
      signedIn = false;
    }
    return signedIn;
  }

  static Future<void> submit(int totalScore) async {
    if (!signedIn) return;
    try {
      await GamesServices.submitScore(
        score: Score(androidLeaderboardID: leaderboardId, value: totalScore),
      );
    } catch (_) {}
  }

  static Future<bool> showLeaderboard() async {
    try {
      if (!signedIn && !await signIn()) return false;
      await GamesServices.showLeaderboards(androidLeaderboardID: leaderboardId);
      return true;
    } catch (_) {
      return false;
    }
  }
}
