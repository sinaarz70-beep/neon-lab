import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/board_screen.dart';
import 'screens/game_screen.dart';
import 'services/play_games.dart';
import 'theme.dart';
import 'widgets/neon_background.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Neon.night,
  ));
  runApp(const NeonLabApp());
  PlayGames.signIn();
}

class NeonLabApp extends StatelessWidget {
  const NeonLabApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'آزمایشگاه نئون',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: Neon.night, useMaterial3: true),
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const Root(),
    );
  }
}

class Root extends StatefulWidget {
  const Root({super.key});
  @override
  State<Root> createState() => _RootState();
}

class _RootState extends State<Root> {
  int tab = 0;
  int score = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(children: [
              const SizedBox(height: 12),
              Align(alignment: AlignmentDirectional.centerStart, child: _tabs()),
              Expanded(
                child: IndexedStack(index: tab, children: [
                  GameScreen(onOpenBoard: () => setState(() => tab = 1), onScore: (s) => setState(() => score = s)),
                  tab == 1 ? BoardScreen(key: ValueKey(score), score: score) : const SizedBox.shrink(),
                ]),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _tabs() {
    Widget item(int i, String label) {
      final on = tab == i;
      return GestureDetector(
        onTap: () => setState(() => tab = i),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
          decoration: BoxDecoration(
            color: on ? Neon.cyan : Colors.transparent,
            borderRadius: BorderRadius.circular(999),
            boxShadow: on ? [BoxShadow(color: Neon.cyan.withOpacity(.7), blurRadius: 18)] : null,
          ),
          child: Text(label, style: Neon.font(size: 14, w: FontWeight.w700, color: on ? Neon.night : Neon.muted)),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.05),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white.withOpacity(.1)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [item(0, 'بازی'), item(1, 'جدول مسابقه')]),
    );
  }
}
