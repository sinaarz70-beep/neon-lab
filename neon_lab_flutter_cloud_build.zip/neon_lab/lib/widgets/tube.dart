import 'package:flutter/material.dart';
import '../game/logic.dart';
import '../theme.dart';

const double kCapSpace = 16;

class TubeView extends StatelessWidget {
  final List<int> tube;
  final double width;
  final double seg;
  final Color? glow;
  final bool flash;
  const TubeView({super.key, required this.tube, required this.width, required this.seg, this.glow, this.flash = false});

  static double heightFor(double seg) => seg * cap + seg * .76 + kCapSpace;

  @override
  Widget build(BuildContext context) {
    final done = tube.isNotEmpty && isDoneTube(tube);
    return SizedBox(
      width: width,
      height: heightFor(seg),
      child: CustomPaint(
        painter: _TubePainter(
          tube: List<int>.from(tube),
          seg: seg,
          glow: done ? Neon.liquids[tube.first] : glow,
          done: done,
          flash: flash,
        ),
      ),
    );
  }
}

class _TubePainter extends CustomPainter {
  final List<int> tube;
  final double seg;
  final Color? glow;
  final bool done;
  final bool flash;
  _TubePainter({required this.tube, required this.seg, this.glow, required this.done, required this.flash});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    const top = kCapSpace;
    final h = size.height - kCapSpace;
    final r = w / 2;
    final body = RRect.fromLTRBAndCorners(0, top, w, top + h, bottomLeft: Radius.circular(r), bottomRight: Radius.circular(r));

    if (glow != null) {
      canvas.drawRRect(
        body,
        Paint()
          ..color = glow!.withOpacity(.7)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 6
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
      );
    }

    canvas.save();
    canvas.clipRRect(body);
    final rect = body.outerRect;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(colors: [
          Colors.white.withOpacity(.05),
          Colors.white.withOpacity(.13),
          Colors.white.withOpacity(.03),
        ]).createShader(rect),
    );
    for (var k = 0; k < tube.length; k++) {
      final bottom = top + h - k * seg;
      final sr = Rect.fromLTRB(0, bottom - seg, w, bottom + .5);
      canvas.drawRect(sr, Paint()..color = Neon.liquids[tube[k]]);
      canvas.drawRect(
        sr,
        Paint()
          ..shader = LinearGradient(
            colors: [Colors.white.withOpacity(.28), Colors.transparent, Colors.black.withOpacity(.18)],
            stops: const [0, .45, 1],
          ).createShader(sr),
      );
    }
    if (tube.isNotEmpty) {
      final y = top + h - tube.length * seg;
      canvas.drawRect(Rect.fromLTWH(0, y, w, 4), Paint()..color = Colors.white.withOpacity(.45));
    }
    if (flash) canvas.drawRect(rect, Paint()..color = Colors.white.withOpacity(.35));
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(w * .15, top + 10, w * .1, h - 26), const Radius.circular(4)),
      Paint()..color = Colors.white.withOpacity(.35),
    );
    canvas.restore();

    final border = Path()
      ..moveTo(0, top)
      ..lineTo(0, top + h - r)
      ..arcToPoint(Offset(w, top + h - r), radius: Radius.circular(r), clockwise: false)
      ..lineTo(w, top);
    canvas.drawPath(
      border,
      Paint()
        ..color = glow ?? Neon.glass
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(-3, top - 2, w + 6, 5), const Radius.circular(3)),
      Paint()..color = glow ?? const Color(0xCCCFC6F0),
    );

    if (done) {
      final c = Neon.liquids[tube.first];
      final capRect = RRect.fromRectAndCorners(
        Rect.fromLTWH(3, 0, w - 6, kCapSpace + 2),
        topLeft: const Radius.circular(6),
        topRight: const Radius.circular(6),
        bottomLeft: const Radius.circular(3),
        bottomRight: const Radius.circular(3),
      );
      canvas.drawRRect(capRect, Paint()..color = c..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
      canvas.drawRRect(capRect, Paint()..color = c);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
