import 'package:flutter/material.dart';
import '../theme.dart';

class NeonTool extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  const NeonTool({super.key, required this.icon, required this.label, this.onTap});

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return Opacity(
      opacity: enabled ? 1 : .3,
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Neon.cyan.withOpacity(.08),
              border: Border.all(color: Neon.cyan, width: 2),
              boxShadow: [BoxShadow(color: Neon.cyan.withOpacity(.55), blurRadius: 16)],
            ),
            child: Icon(icon, color: Neon.cyan, size: 26),
          ),
          const SizedBox(height: 6),
          Text(label, style: Neon.font(size: 14, w: FontWeight.w700, color: const Color(0xFFCFC6F0))),
        ]),
      ),
    );
  }
}

class NeonPill extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback onTap;
  const NeonPill({super.key, required this.label, required this.onTap, this.color = Neon.magenta});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(999),
          boxShadow: [BoxShadow(color: color.withOpacity(.7), blurRadius: 24)],
        ),
        child: Text(label, style: Neon.font(size: 18, w: FontWeight.w900, color: Neon.night)),
      ),
    );
  }
}
