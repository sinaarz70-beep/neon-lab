import 'package:flutter/material.dart';
import '../theme.dart';

/// Midnight lab under blacklight: soft neon haze + a slowly drifting grid.
class NeonBackground extends StatefulWidget {
  final Widget child;
  const NeonBackground({super.key, required this.child});
  @override
  State<NeonBackground> createState() => _NeonBackgroundState();
}

class _NeonBackgroundState extends State<NeonBackground> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 14))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Positioned.fill(child: Container(color: Neon.night)),
      Positioned.fill(
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: RadialGradient(center: const Alignment(.8, -.95), radius: .9, colors: [Neon.magenta.withOpacity(.22), Colors.transparent]),
          ),
        ),
      ),
      Positioned.fill(
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: RadialGradient(center: const Alignment(-.9, 1), radius: 1, colors: [Neon.cyan.withOpacity(.18), Colors.transparent]),
          ),
        ),
      ),
      Positioned.fill(
        child: RepaintBoundary(
          child: AnimatedBuilder(
            animation: _c,
            builder: (_, __) => CustomPaint(painter: _GridPainter(_c.value)),
          ),
        ),
      ),
      Positioned.fill(child: widget.child),
    ]);
  }
}

class _GridPainter extends CustomPainter {
  final double t;
  _GridPainter(this.t);
  @override
  void paint(Canvas canvas, Size size) {
    const step = 26.0;
    final off = t * step;
    for (double y = -step + off; y < size.height; y += step) {
      final a = (y / size.height).clamp(0.0, 1.0) * .10;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), Paint()..color = const Color(0xFFA64DFF).withOpacity(a));
    }
    final vp = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Colors.transparent, const Color(0xFFA64DFF).withOpacity(.10)],
      ).createShader(Offset.zero & size);
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), vp);
    }
  }

  @override
  bool shouldRepaint(_GridPainter old) => old.t != t;
}
