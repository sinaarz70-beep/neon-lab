import 'dart:math';

const int cap = 4;
const int maxColors = 12;

typedef Tubes = List<List<int>>;

Tubes cloneTubes(Tubes t) => t.map((e) => List<int>.from(e)).toList();

bool isDoneTube(List<int> t) =>
    t.isEmpty || (t.length == cap && t.every((x) => x == t.first));

bool isWon(Tubes t) => t.every(isDoneTube);

bool canPour(Tubes t, int a, int b) {
  if (a == b) return false;
  final from = t[a], to = t[b];
  if (from.isEmpty || to.length >= cap) return false;
  if (to.isEmpty) return true;
  return to.last == from.last;
}

class PourResult {
  final Tubes tubes;
  final int moved;
  final int color;
  PourResult(this.tubes, this.moved, this.color);
}

PourResult pour(Tubes t, int a, int b) {
  final next = cloneTubes(t);
  final from = next[a], to = next[b];
  final color = from.last;
  var moved = 0;
  while (from.isNotEmpty && from.last == color && to.length < cap) {
    to.add(from.removeLast());
    moved++;
  }
  return PourResult(next, moved, color);
}

/// Level 1-2: 3 colors, +1 color every 2 levels, capped at 12. Levels never end.
int colorCount(int level) => min(3 + (level - 1) ~/ 2, maxColors);

int pointsFor(int level, int moves, bool usedExtra) {
  final n = colorCount(level);
  final base = max(20, n * 40 - max(0, moves - n * 3) * 2);
  return max(10, base - (usedExtra ? 30 : 0));
}

String _key(Tubes t) {
  final parts = t.map((e) => e.join(',')).toList()..sort();
  return parts.join('|');
}

bool _solvable(Tubes start, {int limit = 60000}) {
  final seen = <String>{};
  final stack = <Tubes>[start];
  while (stack.isNotEmpty) {
    final s = stack.removeLast();
    if (isWon(s)) return true;
    if (!seen.add(_key(s))) continue;
    if (seen.length > limit) return true;
    for (var a = 0; a < s.length; a++) {
      if (s[a].isEmpty || isDoneTube(s[a])) continue;
      final uniform = s[a].every((x) => x == s[a].first);
      var emptyTried = false;
      for (var b = 0; b < s.length; b++) {
        if (!canPour(s, a, b)) continue;
        if (s[b].isEmpty) {
          if (emptyTried || uniform) continue;
          emptyTried = true;
        }
        stack.add(pour(s, a, b).tubes);
      }
    }
  }
  return false;
}

/// Deterministic, always-solvable level for any level number (infinite levels).
Tubes makeLevel(int level) {
  final n = colorCount(level);
  Tubes? last;
  for (var attempt = 0; attempt < 200; attempt++) {
    final rng = Random(level * 7919 + attempt * 104729 + 17);
    final pool = <int>[];
    for (var i = 0; i < n; i++) {
      for (var j = 0; j < cap; j++) {
        pool.add(i);
      }
    }
    pool.shuffle(rng);
    final tubes = <List<int>>[];
    for (var i = 0; i < n; i++) {
      tubes.add(pool.sublist(i * cap, i * cap + cap));
    }
    tubes.add(<int>[]);
    tubes.add(<int>[]);
    last = tubes;
    if (tubes.any((t) => t.isNotEmpty && isDoneTube(t))) continue;
    if (_solvable(cloneTubes(tubes))) return tubes;
  }
  return last!;
}
